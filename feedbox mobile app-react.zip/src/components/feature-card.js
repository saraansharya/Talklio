import React from 'react'

import PropTypes from 'prop-types'

import projectStyles from '../style.module.css'
import styles from './feature-card.module.css'

const FeatureCard = (props) => {
  return (
    <div className={` ${styles['Card']} ${styles[props.rootClassName]} `}>
      <svg viewBox="0 0 1024 1024" className={styles['icon']}>
        <path d="M512 0c-282.77 0-512 229.23-512 512s229.23 512 512 512 512-229.23 512-512-229.23-512-512-512zM320 512c0-106.040 85.96-192 192-192s192 85.96 192 192-85.96 192-192 192-192-85.96-192-192zM925.98 683.476v0l-177.42-73.49c12.518-30.184 19.44-63.276 19.44-97.986s-6.922-67.802-19.44-97.986l177.42-73.49c21.908 52.822 34.020 110.73 34.020 171.476s-12.114 118.654-34.020 171.476v0zM683.478 98.020v0 0l-73.49 177.42c-30.184-12.518-63.276-19.44-97.988-19.44s-67.802 6.922-97.986 19.44l-73.49-177.422c52.822-21.904 110.732-34.018 171.476-34.018 60.746 0 118.654 12.114 171.478 34.020zM98.020 340.524l177.422 73.49c-12.518 30.184-19.442 63.276-19.442 97.986s6.922 67.802 19.44 97.986l-177.42 73.49c-21.906-52.822-34.020-110.73-34.020-171.476s12.114-118.654 34.020-171.476zM340.524 925.98l73.49-177.42c30.184 12.518 63.276 19.44 97.986 19.44s67.802-6.922 97.986-19.44l73.49 177.42c-52.822 21.904-110.73 34.020-171.476 34.020-60.744 0-118.654-12.114-171.476-34.020z"></path>
      </svg>
      <h4 className={` ${styles['text']} ${projectStyles['heading4']} `}>
        {props.heading}
      </h4>
      <span
        className={` ${styles['text1']} ${projectStyles['content-Light']} `}
      >
        {props.text}
      </span>
      <span className={styles['text2']}>{props.text1}</span>
    </div>
  )
}

FeatureCard.defaultProps = {
  text1: 'Get started >',
  rootClassName: '',
  text: "Have a question that's been bugging you or a dilemma you're facing? Post it anonymously and receive real-time feedback from the community.",
  heading: 'Take advice',
}

FeatureCard.propTypes = {
  text1: PropTypes.string,
  rootClassName: PropTypes.string,
  text: PropTypes.string,
  heading: PropTypes.string,
}

export default FeatureCard
