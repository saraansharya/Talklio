import React from 'react'

import PropTypes from 'prop-types'

import projectStyles from '../style.module.css'
import styles from './navigation-links.module.css'

const NavigationLinks = (props) => {
  return (
    <nav className={` ${styles['Nav']} ${styles[props.rootClassName]} `}>
      <span className={` ${styles['text']} ${projectStyles['navbar-link']} `}>
        {props.text1}
      </span>
      <span className={` ${styles['text1']} ${projectStyles['navbar-link']} `}>
        {props.text3}
      </span>
      <span className={` ${styles['text2']} ${projectStyles['navbar-link']} `}>
        {props.text4}
      </span>
    </nav>
  )
}

NavigationLinks.defaultProps = {
  text3: 'Team',
  rootClassName: '',
  text4: 'Contact',
  text1: 'About',
}

NavigationLinks.propTypes = {
  text3: PropTypes.string,
  rootClassName: PropTypes.string,
  text4: PropTypes.string,
  text1: PropTypes.string,
}

export default NavigationLinks
