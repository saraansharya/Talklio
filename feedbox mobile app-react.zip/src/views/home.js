import React from 'react'
import { Link } from 'react-router-dom'

import { Helmet } from 'react-helmet'

import Navbar from '../components/navbar'
import projectStyles from '../style.module.css'
import styles from './home.module.css'

const Home = () => {
  return (
    <div className={styles['container']}>
      <Helmet>
        <title>Feedbox mobile app</title>
        <meta property="og:title" content="Feedbox mobile app" />
      </Helmet>
      <Navbar></Navbar>
      <main className={styles['Main']}>
        <div className={projectStyles['section-container']}>
          <div
            className={` ${styles['max-width']} ${projectStyles['max-content-container']} `}
          >
            <div className={styles['image-container']}>
              <h1 className={styles['text']}>Talklio</h1>
            </div>
          </div>
        </div>
        <div
          className={` ${styles['SectionOne']} ${projectStyles['section-container']} `}
        >
          <div
            className={` ${styles['max-width1']} ${projectStyles['max-content-container']} `}
          >
            <h2
              className={` ${styles['text01']} ${projectStyles['heading2']} `}
            >
              <span>UCL’s hive mind at your fingertips.</span>
              <br></br>
              <span>live, unfiltered, and anonymous.</span>
            </h2>
            <button
              className={` ${styles['button']} ${projectStyles['button-primary']} ${projectStyles['button']} `}
            >
              <span className={styles['text04']}>Join us</span>
            </button>
            <div className={styles['cards-container']}>
              <div className={styles['Card']}>
                <Link to="/page" className={styles['navlink']}>
                  <svg viewBox="0 0 1024 1024" className={styles['icon']}>
                    <path d="M512 192c-54.932 0-107.988 8.662-157.694 25.742-46.712 16.054-88.306 38.744-123.628 67.444-66.214 53.798-102.678 122.984-102.678 194.814 0 40.298 11.188 79.378 33.252 116.152 22.752 37.92 56.982 72.586 98.988 100.252 30.356 19.992 50.78 51.948 56.176 87.894 1.8 11.984 2.928 24.088 3.37 36.124 7.47-6.194 14.75-12.846 21.88-19.976 24.154-24.152 56.78-37.49 90.502-37.49 5.368 0 10.762 0.336 16.156 1.024 20.974 2.666 42.398 4.020 63.676 4.020 54.934 0 107.988-8.66 157.694-25.742 46.712-16.054 88.306-38.744 123.628-67.444 66.214-53.796 102.678-122.984 102.678-194.814s-36.464-141.016-102.678-194.814c-35.322-28.698-76.916-51.39-123.628-67.444-49.706-17.080-102.76-25.742-157.694-25.742zM512 64v0c282.77 0 512 186.25 512 416 0 229.752-229.23 416-512 416-27.156 0-53.81-1.734-79.824-5.044-109.978 109.978-241.25 129.7-368.176 132.596v-26.916c68.536-33.578 128-94.74 128-164.636 0-9.754-0.758-19.33-2.164-28.696-115.796-76.264-189.836-192.754-189.836-323.304 0-229.75 229.23-416 512-416z"></path>
                  </svg>
                </Link>
                <h4
                  className={` ${styles['text05']} ${projectStyles['heading4']} `}
                >
                  Take a stand
                </h4>
                <span
                  className={` ${styles['text06']} ${projectStyles['content-Light']} `}
                >
                  Give your opinion on polarizing topics or answer controversial
                  questions once a day and check out what other UCL students
                  answered.
                </span>
              </div>
              <div className={styles['Card1']}>
                <svg viewBox="0 0 1024 1024" className={styles['icon2']}>
                  <path d="M418 598q0-58 40-98t96-40q58 0 98 40t40 98q0 56-40 96t-98 40-97-39-39-97zM554 810q88 0 151-62t63-150-63-151-151-63-150 63-62 151 62 150 150 62zM256 426v-128h128v-128h298l78 86h136q34 0 60 26t26 60v512q0 34-26 59t-60 25h-682q-34 0-60-25t-26-59v-428h128zM128 170v-128h86v128h128v86h-128v128h-86v-128h-128v-86h128z"></path>
                </svg>
                <h4
                  className={` ${styles['text07']} ${projectStyles['heading4']} `}
                >
                  Take a snap
                </h4>
                <span
                  className={` ${styles['text08']} ${projectStyles['content-Light']} `}
                >
                  At random times each day, you have two minutes to take a
                  picture of yourself in that moment. Snap quick to see what
                  your friends are up to!
                </span>
              </div>
              <div className={styles['Card2']}>
                <svg viewBox="0 0 1024 1024" className={styles['icon4']}>
                  <path d="M512 0c-282.77 0-512 229.23-512 512s229.23 512 512 512 512-229.23 512-512-229.23-512-512-512zM320 512c0-106.040 85.96-192 192-192s192 85.96 192 192-85.96 192-192 192-192-85.96-192-192zM925.98 683.476v0l-177.42-73.49c12.518-30.184 19.44-63.276 19.44-97.986s-6.922-67.802-19.44-97.986l177.42-73.49c21.908 52.822 34.020 110.73 34.020 171.476s-12.114 118.654-34.020 171.476v0zM683.478 98.020v0 0l-73.49 177.42c-30.184-12.518-63.276-19.44-97.988-19.44s-67.802 6.922-97.986 19.44l-73.49-177.422c52.822-21.904 110.732-34.018 171.476-34.018 60.746 0 118.654 12.114 171.478 34.020zM98.020 340.524l177.422 73.49c-12.518 30.184-19.442 63.276-19.442 97.986s6.922 67.802 19.44 97.986l-177.42 73.49c-21.906-52.822-34.020-110.73-34.020-171.476s12.114-118.654 34.020-171.476zM340.524 925.98l73.49-177.42c30.184 12.518 63.276 19.44 97.986 19.44s67.802-6.922 97.986-19.44l73.49 177.42c-52.822 21.904-110.73 34.020-171.476 34.020-60.744 0-118.654-12.114-171.476-34.020z"></path>
                </svg>
                <h4
                  className={` ${styles['text09']} ${projectStyles['heading4']} `}
                >
                  Take advice
                </h4>
                <span
                  className={` ${styles['text10']} ${projectStyles['content-Light']} `}
                >
                  Have a question that&apos;s been bugging you or a dilemma
                  you&apos;re facing? Post it anonymously and receive real-time
                  feedback.
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className={projectStyles['section-container']}>
          <div
            className={` ${styles['max-width2']} ${projectStyles['max-content-container']} `}
          >
            <div className={styles['heading-container']}></div>
            <div className={styles['get-the-app']}>
              <img
                alt="image"
                src="/playground_assets/frame-1200w.png"
                className={styles['image']}
              />
              <img
                alt="image"
                src="/playground_assets/frame%2034-200h.png"
                className={styles['image1']}
              />
            </div>
            <div className={styles['cards-container1']}></div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default Home
