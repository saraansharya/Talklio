import React from 'react'
import { Link } from 'react-router-dom'

import { Helmet } from 'react-helmet'

import projectStyles from '../style.module.css'
import styles from './page.module.css'

const Page = () => {
  return (
    <div className={styles['container']}>
      <Helmet>
        <title>Page - Feedbox mobile app</title>
        <meta property="og:title" content="Page - Feedbox mobile app" />
      </Helmet>
      <div className={styles['container1']}>
        <h1 className={styles['text']}>
          <br></br>
          <span>Question:</span>
          <br></br>
          <span></span>
        </h1>
        <span className={styles['text05']}>
          <span>Pineapple on pizza?</span>
          <br></br>
          <span></span>
        </span>
        <div className={styles['container2']}>
          <input
            type="text"
            placeholder="placeholder"
            className={projectStyles['input']}
          />
          <Link
            to="/page1"
            className={` ${styles['navlink']} ${projectStyles['button']} `}
          >
            <span className={styles['text09']}>
              <span>Post</span>
              <span className={styles['text11']}></span>
            </span>
          </Link>
        </div>
      </div>
    </div>
  )
}

export default Page
